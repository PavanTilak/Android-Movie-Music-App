package com.example.dictionaryapp

import android.content.Intent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.MediumTest
import androidx.test.rule.ActivityTestRule
import androidx.test.runner.AndroidJUnit4
import com.backbase.assignment.R
import com.backbase.assignment.ui.MainActivity
import org.hamcrest.CoreMatchers.instanceOf
import org.hamcrest.CoreMatchers.notNullValue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.hamcrest.Matchers.not

@MediumTest
@RunWith(AndroidJUnit4::class)
class MainActivityTest {


    //@Rule
    //var activityTestRule = ActivityTestRule(MainActivity::class.java)

    @get:Rule
    var mActivityRule: ActivityTestRule<MainActivity> = ActivityTestRule(MainActivity::class.java)

    @Test
    fun launchActivity() {
        val intent = Intent()
        mActivityRule.launchActivity(intent)
    }

    @Test
    fun initialiseView() {
        val activity = mActivityRule.activity
        val viewById = activity.findViewById<View>(R.id.currentPlaying)
        assertThat(viewById, notNullValue())
        assertThat(viewById, instanceOf<Any>(TextView::class.java))
    }

    @Test
    fun removeText() {
        onView(withId(R.id.currentPlaying)).check(matches(not(withText(""))));
    }

    @Test
    fun performClick() {
        onView(withId(R.id.currentPlaying))
                .perform(click())
    }
}