package com.backbase.assignment.ui.backend;

import android.app.Activity;
import io.reactivex.Observable;
import android.os.StrictMode;
import android.util.Log;

import com.backbase.assignment.ui.utilities.Utils;
import com.backbase.assignment.ui.interfaces.IApiResponseCallback;
import com.backbase.assignment.ui.interfaces.IAwsMovieData;
import com.backbase.assignment.ui.model.PlayingMovieModel;

import java.util.ArrayList;
import java.util.List;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import static com.backbase.assignment.ui.utilities.Utils.API_KEY;
import static com.backbase.assignment.ui.utilities.Utils.LANGUAGE;


public class ApiCall{

    private IApiResponseCallback iApiResponseCallback = null;
    private final String TAG = "ApiCall";

    public void invokeApiCall(Activity activity) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        iApiResponseCallback = (IApiResponseCallback)activity;

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Utils.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();

        List<Observable<PlayingMovieModel>> requests = new ArrayList<>();
        requests.add(retrofit.create(IAwsMovieData.class).getPlayingMovies(LANGUAGE, "undefined", API_KEY));
        requests.add(retrofit.create(IAwsMovieData.class).getPopularMovies(LANGUAGE, "1", API_KEY));


        // Zip all requests with the Function, which will receive the results.
        Observable.zip(
                requests,
                new Function<Object[], List<PlayingMovieModel>>() {
                    @Override
                    public List<PlayingMovieModel> apply(Object[] objects) {
                        Log.d(TAG+"onSubscribe", "apply: " + objects.length);
                        List<PlayingMovieModel> dataaResponses = new ArrayList<>();
                        for (Object o : objects) {
                            dataaResponses.add((PlayingMovieModel) o);
                        }
                        return dataaResponses;
                    }
                })
                .subscribe(
                        new Consumer<List<PlayingMovieModel>>() {
                            @Override
                            public void accept(List<PlayingMovieModel> dataResponses) {

                                if(dataResponses!=null && dataResponses.size() > 0) {
                                    Log.d(TAG+"onSubscribe", "YOUR DATA IS HERE: " + dataResponses);
                                    iApiResponseCallback.onApiResponse(dataResponses);
                                }
                            }
                        },

                        new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable e) {
                                Log.e(TAG+"onSubscribe", "Throwable: " + e);
                            }
                        }
                );
    }

}
