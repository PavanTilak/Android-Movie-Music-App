package com.backbase.assignment.ui.model;

import java.io.Serializable;
import java.util.List;

/**
 * {
 * "results": [
         * {
         * "popularity": 66.197,
         * "vote_count": 2681,
         * "video": false,
         * "poster_path": "/8WUVHemHFH2ZIP6NWkwlHWsyrEL.jpg",
         * "id": 338762,
         * "adult": false,
         * "backdrop_path": "/lP5eKh8WOcPysfELrUpGhHJGZEH.jpg",
         * "original_language": "en",
         * "original_title": "Bloodshot",
         * "genre_ids": [
         * 28,
         * 878
         * ],
         * "title": "Bloodshot",
         * "vote_average": 7,
         * "overview": "After he and his wife are murdered, marine Ray Garrison is resurrected by a team of scientists. Enhanced with nanotechnology, he becomes a superhuman, biotech killing machine—'Bloodshot'. As Ray first trains with fellow super-soldiers, he cannot recall anything from his former life. But when his memories flood back and he remembers the man that killed both him and his wife, he breaks out of the facility to get revenge, only to discover that there's more to the conspiracy than he thought.",
         * "release_date": "2020-03-05"
         * },
         * ],
 * "page": 1,
 * "total_results": 585,
 * "dates": {
         * "maximum": "2020-06-21",
         * "minimum": "2020-05-04"
         * },
 * "total_pages": 30
 * }
 *
 *
 *
 */

public class PlayingMovieModel implements Serializable {

    List<Results> results;
    private int page;
    private int total_results;
    Dates dates;
    private int total_pages;

    public List<Results> getResults() {
        return results;
    }

    public void setResults(List<Results> results) {
        this.results = results;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public Dates getDates() {
        return dates;
    }

    public void setDates(Dates dates) {
        this.dates = dates;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public PlayingMovieModel(List<Results> results, int page, int total_results, Dates dates, int total_pages) {
        this.results = results;
        this.page = page;
        this.total_results = total_results;
        this.dates = dates;
        this.total_pages = total_pages;
    }
}
