package com.backbase.assignment.ui.interfaces;

import com.backbase.assignment.ui.model.PlayingMovieModel;

import java.util.List;

public interface IApiResponseCallback {
    void onApiResponse(List<PlayingMovieModel> playingMovieModel);
}
