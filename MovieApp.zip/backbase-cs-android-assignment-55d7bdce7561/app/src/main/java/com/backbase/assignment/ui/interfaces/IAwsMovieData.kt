package com.backbase.assignment.ui.interfaces


import com.backbase.assignment.ui.model.PlayingMovieModel
import com.google.gson.JsonObject
import io.reactivex.Observable
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query


interface IAwsMovieData {

    @GET("movie/now_playing")
    fun getPlayingMovies(@Query("language") language: String,
                          @Query("page") page: String,
                          @Query("api_key") api_key: String): Observable<PlayingMovieModel>

    @GET("movie/popular")
    fun getPopularMovies(@Query("language") language: String,
                         @Query("page") page: String,
                         @Query("api_key") api_key: String): Observable<PlayingMovieModel>
}
