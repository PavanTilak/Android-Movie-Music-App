package com.backbase.assignment.ui.custom;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.backbase.assignment.R;
import com.backbase.assignment.ui.model.Results;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import static com.backbase.assignment.ui.utilities.Utils.MOVIE_OBJ;

public class MovieDetails extends AppCompatActivity {

    private ImageView mImageView;
    private TextView mTitle , mDurationRelDate , mOverview;
    private Results results = null;
    private Toolbar mToolbar = null;
    AlertDialog.Builder builder;
    AlertDialog dialog=null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_details);

        results = new Gson().fromJson(getIntent().getStringExtra(MOVIE_OBJ).toString() , Results.class);

        initViews();

        if(results != null) {
            updateViewsContent();
        }
    }

    private void initViews() {
        mToolbar = findViewById(R.id.lToolbar);
        TextView title = mToolbar.findViewById(R.id.toolbar_title);
        title.setVisibility(View.GONE);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        mImageView = findViewById(R.id.mImageView);
        mTitle = findViewById(R.id.mTitle);
        mDurationRelDate = findViewById(R.id.mDurationRelDate);
        mOverview = findViewById(R.id.mOverview);
    }

    private void updateViewsContent() {
        mTitle.setText(results.getTitle());
        mDurationRelDate.setText(results.getRelease_date());
        mOverview.setText(results.getOverview());
        String imageUri = "https://image.tmdb.org/t/p/original"+results.getPoster_path();
        Picasso.get().load(imageUri).into(mImageView);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

}
