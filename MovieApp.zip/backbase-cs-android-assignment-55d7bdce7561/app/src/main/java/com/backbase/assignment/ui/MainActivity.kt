package com.backbase.assignment.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.ImageView.ScaleType
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backbase.assignment.R
import com.backbase.assignment.ui.adapters.MoviesAdapter
import com.backbase.assignment.ui.backend.ApiCall
import com.backbase.assignment.ui.interfaces.IApiResponseCallback
import com.backbase.assignment.ui.model.PlayingMovieModel
import com.backbase.assignment.ui.model.Results
import com.backbase.assignment.ui.utilities.Utils.checkNetworkState
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.reflect.TypeToken
import com.squareup.picasso.Picasso


class MainActivity : AppCompatActivity(), IApiResponseCallback {

    private lateinit var moviesAdapter: MoviesAdapter
    private lateinit var recyclerView: RecyclerView
    private var mLinearLayout: LinearLayout? = null
    var builder: AlertDialog.Builder? = null
    var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews();

        //Condition to check internet connected
        if(checkNetworkState(this)) {
            displayProgressDialog()
            ApiCall().invokeApiCall(this)
        } else {
            Toast.makeText(this, resources.getText(R.string.network_error), Toast.LENGTH_LONG).show()
        }
    }

    private fun displayProgressDialog() {
        builder = AlertDialog.Builder(this)
        builder!!.setCancelable(false) // if you want user to wait for some process to finish,
        builder!!.setView(R.layout.layout_loading_dialog)
        dialog = builder!!.create()
        dialog?.show()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = layoutManager
        moviesAdapter = MoviesAdapter()
        recyclerView.adapter = moviesAdapter
        mLinearLayout = findViewById(R.id.linear_view)
    }


    override fun onApiResponse(playingMovieModel: MutableList<PlayingMovieModel>?) {

        //This block for displaying Currently Playing movie list
        val currentMovieList: PlayingMovieModel? = playingMovieModel?.get(0)
        val resultList = currentMovieList!!.results
        for (i in resultList.indices) {
            val imageView = ImageView(this)
            imageView.setId(i)
            imageView.setPadding(2, 2, 2, 2)
            Picasso.get().load("https://image.tmdb.org/t/p/original${resultList[i].poster_path}").into(imageView)
            imageView.layoutParams = LinearLayout.LayoutParams(resources.getDimension(R.dimen.imgW).toInt(), resources.getDimension(R.dimen.imgH).toInt())
            imageView.setScaleType(ScaleType.FIT_XY)
            mLinearLayout?.addView(imageView)
        }

        //This block for displaying Most popular Movie images in Horizontal scrollview
        val popularMovieList: PlayingMovieModel? = playingMovieModel?.get(1)
        val resultJsonArray = Gson().toJsonTree(
            popularMovieList?.results,
            object : TypeToken<List<Results?>?>() {}.type
        ) as JsonArray
        moviesAdapter.items = resultJsonArray
        moviesAdapter.notifyDataSetChanged()

        //dismiss the progress dialog
        dialog?.dismiss()
    }
}
