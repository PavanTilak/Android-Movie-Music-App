package com.backbase.assignment.ui.adapters

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.RecyclerView
import com.backbase.assignment.R
import com.backbase.assignment.ui.utilities.Utils.MOVIE_OBJ
import com.backbase.assignment.ui.custom.MovieDetails
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso

class MoviesAdapter(var items: JsonArray = JsonArray()) :
    RecyclerView.Adapter<MoviesAdapter.ViewHolder>() {
    var mActivity : Activity? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        mActivity = parent.context as Activity

        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.movie_item,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position] as JsonObject)

        holder.itemView.setOnClickListener {
            val bundle = Bundle()
            bundle.putString(MOVIE_OBJ, items.get(position).toString())
            val intent = Intent(mActivity, MovieDetails::class.java)
            intent.putExtras(bundle)

            mActivity?.startActivity(intent)
        }
    }

    override fun getItemCount() = items.size()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        lateinit var poster: ImageView
        lateinit var title: TextView
        lateinit var releaseDate: TextView
        lateinit var progressBar: ProgressBar
        lateinit var progressText: TextView

        fun bind(item: JsonObject) = with(itemView) {
            poster = itemView.findViewById(R.id.poster)
            Picasso.get().load("https://image.tmdb.org/t/p/original${item["poster_path"].asString}").into(poster)

            title = itemView.findViewById(R.id.title)
            title.text = item["title"].asString

            releaseDate = itemView.findViewById(R.id.releaseDate)
            releaseDate.text = item["release_date"].asString


            var rating = item["vote_average"]

            progressText = itemView.findViewById(R.id.txtProgress)
            progressText.text = rating.asString

            progressBar = itemView.findViewById(R.id.progressBar)
            progressBar.progress = rating.asInt

            if(rating.asInt < 5) {
                DrawableCompat.setTint(progressBar.progressDrawable, Color.YELLOW)
            } else {
                DrawableCompat.setTint(progressBar.progressDrawable, Color.GREEN)
            }
        }
    }
}